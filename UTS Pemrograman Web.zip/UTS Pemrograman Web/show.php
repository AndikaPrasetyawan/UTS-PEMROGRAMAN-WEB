<?php
include 'config.php';
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM peminjaman WHERE id = $id");
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Detail Peminjaman Buku</title>
    <link rel="stylesheet" type="text/css" href="styleshow.css">
</head>
<body>
    <div class="container">
        <h1>Detail Peminjaman Buku</h1>
        <p>ID: <?= $row['id'] ?></p>
        <p>NIM: <?= $row['nim'] ?></p>
        <p>Nama: <?= $row['nama'] ?></p>
        <p>Tanggal Peminjaman: <?= $row['tanggal_peminjaman'] ?></p>
        <p>Tanggal Pengembalian: <?= $row['tanggal_pengembalian'] ?></p>
        <button><a href="index.php">Kembali</a></button>
    </div>
</body>
</html>
