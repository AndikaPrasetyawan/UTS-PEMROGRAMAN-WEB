<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $judul_buku = $_POST['judul_buku'];
    $tanggal_peminjaman = $_POST['tanggal_peminjaman'];
    $tanggal_pengembalian = $_POST['tanggal_pengembalian'];

    $sql = "INSERT INTO peminjaman (nim, nama, judul_buku, tanggal_peminjaman, tanggal_pengembalian) VALUES ('$nim', '$nama', '$judul_buku', '$tanggal_peminjaman', '$tanggal_pengembalian')";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php"); 
        exit(); 
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Daftar Peminjaman Buku</title>
    <link rel="stylesheet" type="text/css" href="stylecreate.css">
</head>
<body>
    <div class="form-container">
        <h1>Tambah Daftar Peminjaman Buku</h1>
        <p>Silahkan tambah daftar peminjaman buku sesuai data yang ada di perpustakaan</p>
        <form method="POST" action="">
            <label for="nim">NIM:</label>
            <input type="text" id="nim" name="nim" required>

            <label for="nama">Nama:</label>
            <input type="text" id="nama" name="nama" required>

            <label for="judul_buku">Judul Buku:</label>
            <input type="text" id="judul_buku" name="judul_buku" required>

            <label for="tanggal_peminjaman">Tanggal Meminjam:</label>
            <input type="date" id="tanggal_peminjaman" name="tanggal_peminjaman" required>

            <label for="tanggal_pengembalian">Tanggal Pengembalian:</label>
            <input type="date" id="tanggal_pengembalian" name="tanggal_pengembalian" required>

            <input type="submit" value="Submit">
        </form>
        <a href="index.php">Kembali</a>
    </div>
</body>
</html>
