CREATE DATABASE perpustakaan;

USE perpustakaan;

CREATE TABLE peminjaman (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nim VARCHAR(10) NOT NULL,
    nama VARCHAR(100) NOT NULL,
    judul_buku VARCHAR(200) NOT NULL,
    tanggal_peminjaman DATE NOT NULL,
    tanggal_pengembalian DATE NOT NULL
);
