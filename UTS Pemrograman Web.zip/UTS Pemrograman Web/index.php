<?php
include 'config.php';
$result = $conn->query("SELECT * FROM peminjaman");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Peminjaman Buku</title>
    <link rel="stylesheet" type="text/css" href="styleindex.css">
</head>
<body>
    <div class="container">
        <h1>Data Peminjaman Buku</h1>
        <button><a href="create.php">Tambah Data</a></button>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Judul buku</th>
                <th>Tanggal Peminjaman</th>
                <th>Tanggal Pengembalian</th>
                <th>Aksi</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['nim'] ?></td>
                <td><?= $row['nama'] ?></td>
                <td><?= $row['judul_buku'] ?></td>
                <td><?= $row['tanggal_peminjaman'] ?></td>
                <td><?= $row['tanggal_pengembalian'] ?></td>
                <td>
                    <button><a href="show.php?id=<?= $row['id'] ?>">Detail</a></button>
                    <button><a href="update.php?id=<?= $row['id'] ?>">Edit</a></button>
                    <button><a href="delete.php?id=<?= $row['id'] ?>">Hapus</a></button>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>
